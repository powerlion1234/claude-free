# Claude Free – Android project

This project adds a native chat screen to the FreeLLMAPI Android app. The chat screen calls the local OpenAI-compatible API at `http://127.0.0.1:3001/v1`.

## Important status

This is **source code, not an installable APK**. The app has not yet been built or tested on a physical phone. The router's previous crash on Android 16 is not proven fixed by these changes.

## Build APK with GitHub Actions

The workflow at `.github/workflows/build.yml` is configured to:

1. Install Java and the Android SDK/NDK.
2. Install the Node.js server dependencies into the Android assets folder.
3. Download the nodejs-mobile Android runtime and its headers.
4. Build the debug APKs and publish them as a workflow artifact.

To use it, the updated project must be pushed to the `main` branch of a GitHub repository (or the workflow must be started manually from the repository's Actions tab). Then open the completed **Build Android APK** workflow run and download the `claude-free-debug-apks` artifact.

## Local prerequisites

- JDK 17
- Android SDK Platform 34
- Android NDK 26.1.10909125
- CMake 3.22.1
- Node.js 20 (for installing the server's npm dependencies)

## Build locally

```bash
cd android/app/src/main/assets/nodejs-project
npm install --omit=dev
cd ../../../../../
./gradlew assembleDebug
```

The native `nodejs-mobile` libraries must also be placed in `android/app/libnode/bin/<ABI>/libnode.so`, with headers in `android/app/libnode/include/node/` before a local build.

## Notes

- The app currently uses the default router key `freellmapi`.
- `Claude Free` is a UI name; it does not provide Anthropic Claude models by itself. It displays the models exposed by the configured FreeLLMAPI providers.
- A successful CI build only proves that the APK compiles. Runtime testing on the Poco F7 is still required.
