package com.freellmapi.android

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Claude-inspired chat UI for the local FreeLLMAPI OpenAI-compatible endpoint. */
class ChatActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val messages = JSONArray()
    private lateinit var transcript: LinearLayout
    private lateinit var input: EditText
    private lateinit var model: Spinner
    private val baseUrl = "http://127.0.0.1:3001/v1"
    private val apiKey = "freellmapi"
    private val purple = Color.rgb(112, 86, 166)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(24, 24, 24)
        window.navigationBarColor = Color.rgb(24, 24, 24)
        buildUi()
        addBubble("Claude Free", "Verbinde mich mit FreeLLMAPI …", false)
        loadModels()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(20,20,20)); setPadding(16,12,16,12) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "Claude Free"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val back = Button(this).apply { text = "Zurück"; setOnClickListener { finish() } }
        header.addView(back); root.addView(header)
        model = Spinner(this)
        root.addView(model, LinearLayout.LayoutParams(-1, -2))
        val scroll = ScrollView(this)
        scroll.setFillViewport(true)
        transcript = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,12,0,12) }
        scroll.addView(transcript)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val composer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply { hint = "Schreib eine Nachricht …"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setBackgroundColor(Color.rgb(42,42,42)); minLines = 1; maxLines = 4; setPadding(12,8,12,8) }
        composer.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        val send = Button(this).apply { text = "Senden"; setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple)); setTextColor(Color.WHITE); setOnClickListener { sendMessage() } }
        composer.addView(send); root.addView(composer)
        setContentView(root)
    }

    private fun request(path: String, method: String = "GET", body: JSONObject? = null): JSONObject {
        val conn = (URL("$baseUrl$path").openConnection() as HttpURLConnection)
        conn.requestMethod = method; conn.connectTimeout = 12000; conn.readTimeout = 90000
        conn.setRequestProperty("Authorization", "Bearer $apiKey")
        conn.setRequestProperty("Content-Type", "application/json")
        if (body != null) { conn.doOutput = true; conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) } }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) throw Exception("HTTP $code: $text")
        return JSONObject(text)
    }

    private fun loadModels() {
        executor.execute {
            try {
                val data = request("/models").optJSONArray("data") ?: JSONArray()
                val names = mutableListOf("auto")
                for (i in 0 until data.length()) names.add(data.getJSONObject(i).optString("id"))
                runOnUiThread { model.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names.distinct()) }
            } catch (e: Exception) { runOnUiThread { addBubble("System", "Router nicht erreichbar. Starte zuerst FreeLLMAPI. Details: ${e.message}", false) } }
        }
    }

    private fun sendMessage() {
        val text = input.text.toString().trim(); if (text.isEmpty()) return
        input.setText(""); messages.put(JSONObject().put("role", "user").put("content", text)); addBubble("Du", text, true)
        val selected = model.selectedItem?.toString() ?: "auto"
        executor.execute {
            try {
                val payload = JSONObject().put("model", selected).put("messages", messages)
                val result = request("/chat/completions", "POST", payload)
                val answer = result.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "(Leere Antwort)")
                messages.put(JSONObject().put("role", "assistant").put("content", answer))
                runOnUiThread { addBubble("Claude Free", answer, false) }
            } catch (e: Exception) { runOnUiThread { addBubble("Fehler", e.message ?: "Unbekannter Fehler", false) } }
        }
    }

    private fun addBubble(who: String, text: String, user: Boolean) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14,10,14,10); setBackgroundColor(if (user) Color.rgb(55,48,70) else Color.rgb(38,38,38)) }
        val label = TextView(this).apply { this.text = who; textSize = 12f; setTextColor(if (user) 0xFFD4C4FF.toInt() else 0xFFB8A4E8.toInt()); typeface = Typeface.DEFAULT_BOLD }
        val content = TextView(this).apply { this.text = text; textSize = 15f; setTextColor(Color.WHITE); setPadding(0,5,0,0) }
        card.addView(label); card.addView(content)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 10; transcript.addView(card, lp)
    }

    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
